$(document).ready(function() {

	$('#pagepiling').pagepiling(); //You need to initialize the the div with the pagepiling function();

});
